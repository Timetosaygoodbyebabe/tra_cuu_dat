@echo off
chcp 65001 > nul
title Tra Cuu Gia Dat Da Nang - IOC 1022 Backend
echo ======================================================================
echo       HỆ THỐNG TRA CỨU GIÁ ĐẤT TP ĐÀ NẴNG - BACKEND DỊCH VỤ IOC 1022
echo ======================================================================
echo.
echo  * Host: http://0.0.0.0:5000
echo  * Swagger API Docs: http://localhost:5000/swagger
echo  * Tự động đồng bộ dữ liệu từ: https://ioc-api.1022.vn/api/gia-dat/
echo.
echo Đang khởi động máy chủ... Nhấn Ctrl+C để dừng.
echo ----------------------------------------------------------------------
dotnet LandPriceApi.dll --urls "http://0.0.0.0:5000"
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [LỖI] Không thể khởi động ứng dụng.
    echo Vui lòng đảm bảo máy chủ đã cài đặt .NET 8 Hosting Bundle hoặc .NET 8 Runtime:
    echo https://dotnet.microsoft.com/en-us/download/dotnet/8.0
    echo.
    pause
)
